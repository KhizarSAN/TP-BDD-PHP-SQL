<?php
     session_start();
  
   @$mail=$_POST["mail"]; 
   @$pass=$_POST["pass"];
   @$repass=$_POST["repass"];
   @$valider=$_POST["valider"];
   $erreur="";
   if(!isset($valider)){
     
      elseif(empty($mail)) $erreur="Mail laissé vide!"; 
      elseif(empty($pass)) $erreur="Mot de passe laissé vide!";
      elseif($pass!=$repass) $erreur="Mots de passe non identiques!";
      else{
        
         $sel=$pdo->prepare("select id from utilisateur where login=? limit 1");
         $sel->execute(array($login));
         $tab=$sel->fetchAll();
         if(count($tab)>0)
            $erreur="Login existe déjà!";
         else{
            $ins=$pdo->prepare("insert into utilisateur(mail,pass) values(?,?)");
            if($ins->execute(array($mail,md5($pass))))
               header("location: login.php");
         }   
      }
   }
?>