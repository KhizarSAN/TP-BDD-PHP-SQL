  <?php
            $servername = 'localhost';
            $username = 'user';
            $password = 'vi0T*3y33';
            
            //On établit la connexion
            $conn = new PDO("mysql:host=$servername;dbname=exo", $username, $password);
		
			
       

		?>