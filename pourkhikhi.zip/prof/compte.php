


<html>
<?php
	 
	

include("require/header.php");

	?>
	
<br> <br>

 <center>
<div class="form-group">
  <label class="col-md-4 control-label">Prénom</label>  
 
  <input  name="first_name" placeholder="<?php echo $_SESSION["prenom"]; ?>" class="form-control"  type="text" readonly>
    </div>
 

 
<div class="form-group">
  <label class="col-md-4 control-label" >Nom</label> 
   
 
  <input name="last_name" placeholder="<?php echo $_SESSION["nom"]; ?>" class="form-control"  type="text" readonly>
    </div>
 

<!-- Text input-->
       <div class="form-group">
  <label class="col-md-4 control-label">Login</label>  
 
  <input name="email" placeholder="<?php echo $_SESSION["login"]; ?>" class="form-control"  type="text" readonly>
    </div>
 

	</center>