<?php
include("/connexion.php");
include("require/header.php");

$host = 'localhost';
  $dbname = 'exo';
  $username = 'user';
  $password = 'vi0T*3y33';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
   
  $sql = "SELECT * FROM classes";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>

<html>
<link rel=stylesheet type="text/css" href="../style/css/style2.css"/>
	
<br> <br>

 <center>
<p>
	Espace Professeur <br>   Bonjour <strong> <?php echo $_SESSION["prenom"]; ?> </strong> </p>
	
	 
 


	 
	 <br><br><br>
	 
 
<body>

<h4>Dernières Informations</h4>
 

<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="../style/images/img1.jpg" style="width:50%">
  <div class="text">Nouvelles du jour</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="../style/images/img2.jpg" style="width:50%">
  <div class="text">Soleil toujours là !!!</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="../style/images/img3.jpg" style="width:50%">
  <div class="text">COUCOU</div>
</div>

</div>
<br>

 
 

 

   <thead>
     <tr>
		 <br><br><br><br><br><br><br> 
       <th>Classes :</th>
       
	 
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
		<br> 
		 <td><?php echo htmlspecialchars($row['nom']); ?> <a href="#">Accéder à la classe </a></td>
 
     </tr>
     <?php endwhile; ?>
   </tbody>
 </table>
	 
	 <script src="../style/js/slide.js"> </script>
	 
	</center>