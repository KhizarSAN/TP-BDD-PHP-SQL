<?php
   session_start();
$pseudo=   $_SESSION["prenomNom"];
   if($_SESSION["autoriser"]!="oui"){
      header("location:login.php");
	   
      exit();
   }
if($_SESSION["prof"]!="0"){
      header("location:../prof/index.php");
	exit();
}

?>
<html>
	<link rel=stylesheet type="text/css" href="/style/css/style1.css"/>
	<head>
	<title>Espace Membre</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<body id="myPage">


	 
	<div class="w3-top">
	 <div class="w3-bar w3-theme-d2 w3-left-align">
	  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-hover-white w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
 
	  <a href="index.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Accueil</a>

	  <a href="note.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Notes</a>
	<a href="professeurs.php" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Mes professeurs</a>
	 

	  <img src="/style/images/user.png" width="2%" class="w3-right"> <a class="w3-right w3-bar-item  w3-hide-small  "><?php echo $_SESSION["prenom"]; ?></a> 
	  <a href="compte.php" class="w3-bar-item w3-button w3-hide-small w3-right w3-hover-teal" >Mon compte</a>
	  <a href="../deconnexion.php" class="w3-bar-item w3-button w3-hide-small w3-right w3-hover-teal" >Se déconnecter</a>
	 </div>

	  
	</div>