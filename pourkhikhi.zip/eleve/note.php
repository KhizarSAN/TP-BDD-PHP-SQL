<?php
	include('require/header.php');
	
require('../connexion.php');

//$note = $bdd->prepare('SELECT  * FROM note GROUP BY categorie DESC LIMIT 10');
//$note->execute();
	?>


<br><br>


<center> <h1> Notes </h1> </center>

<!--
    <div class="divider"></div> 
    <div class="collection-wrapper">
      <div class="container">
        <div class="row">
          <div class="col-7">
            <div class="section-heading">
              <h2 class="mb-0 ms-3">Voir par catégories</h2>
            </div>
          </div>
          <div class="col-5 text-end"><a class="btn rounded-pill btn-outline-primary btn-sm border-2" href="categories.php">Voir toutes les catégories</a></div>
        </div>
      </div>
      <div class="container">
        <div class="row g-4 justify-content-center">
         
          <?php

          while($notes = $note->fetch()){
            ?>
          <div class="col-12 col-md-10 col-lg-4">
            <div class="catagory-card card shadow-sm">
              <div class="card-body">
                <div class="row g-1">
                </div>
                <div class="row mt-3">
                  <div class="col-8">
                    <h5 class="mb-0"><?php echo $notes['id']; ?><span class="badge bg-primary ms-2"><?php echo $notes['id']; ?></span></h5>
                  </div>
                  <div class="col-4 text-end"><a href="categorie.php?categorie=<?php echo $notes['id']; ?>" >Tout voir<i class="ms-1 fz-14 bi bi-arrow-right"></i></a></div>
                </div>
              </div>
            </div>
          </div>
                          <?php
                        }

                        ?>
			-->
  

	
</table>