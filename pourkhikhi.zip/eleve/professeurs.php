<?php
include("/connexion.php");
include("require/header.php");


  $host = 'localhost';
  $dbname = 'exo';
  $username = 'user';
  $password = 'vi0T*3y33';
    
  $dsn = "mysql:host=$host;dbname=$dbname"; 
  $idclasse = $_SESSION["classeid"];
  $sql = "SELECT prenom, nom FROM users WHERE perm=1 && classeid=$idclasse";
   
  try{
   $pdo = new PDO($dsn, $username, $password);
   $stmt = $pdo->query($sql);
   
   if($stmt === false){
    die("Erreur");
   }
   
  }catch (PDOException $e){
    echo $e->getMessage();
  }
?>


<html>

<br> <br>

 <center>
<h1>

	
	 
<html>

<body>
 <h1>Mes professeurs</h1>
 <table>
   <thead>
     <tr>
		 
        
       <th>Nom</th>
	 
     </tr>
   </thead>
   <tbody>
     <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
		 
        
       <td><?php echo htmlspecialchars($row['nom']); ?></td>
     </tr>
     <?php endwhile; ?>
   </tbody>
 </table>
</body>
</html>
</h1>

	</center>